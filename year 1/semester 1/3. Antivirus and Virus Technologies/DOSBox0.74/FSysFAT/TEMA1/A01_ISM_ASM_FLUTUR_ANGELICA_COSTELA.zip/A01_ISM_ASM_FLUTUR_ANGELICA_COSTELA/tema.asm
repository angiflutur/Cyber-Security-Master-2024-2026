.model small
.stack 100h

.data
    arr1 dw 15, 9, 6, 25  
    arr1_size dw 4          

    arr2 dw 7, 9, 0, 12, 6, 8 
    arr2_size dw 6          

    arr3 dw 6, 19, 3, 5, 9, 15, 7, 10 
    arr3_size dw 8         

	min dw 0FFFFh         
    max dw 0    

.code

start:
    mov ax, @data
    mov ds, ax        

    mov si, offset arr1      
    mov cx, arr1_size        
    call find_min_max

    mov si, offset arr2    
    mov cx, arr2_size        
    call find_min_max

    mov si, offset arr3     
    mov cx, arr3_size        
    call find_min_max

    mov ax, 4C00h
    int 21h

find_min_max:
    mov min, 0FFFFh     
    mov max, 0             

    mov ax, [si]             
    mov min, ax           
    mov max, ax        
    add si, 2               
    dec cx                    

process_loop:
    cmp cx, 0               
    je return         

    mov ax, [si]            
    cmp ax, min   
    jge check_max          
    mov min, ax       

check_max:
    cmp ax, max     
    jle skip_update_max     
    mov max, ax       

skip_update_max:
    add si, 2               
    dec cx                   
    jmp process_loop        

return:
    ret                     

end start
